package database

import (
	"database/sql"
	"fmt"

	"gorm.io/driver/mysql"
	"gorm.io/gorm"

	"recipe-app/backend/config"
	"recipe-app/backend/models"
)

// DB 全局数据库连接
var DB *gorm.DB

// InitDB 初始化数据库连接
func InitDB(cfg config.DatabaseConfig) (*sql.DB, error) {
	dsn := fmt.Sprintf("%s:%s@tcp(%s:%d)/%s?charset=utf8mb4&parseTime=True&loc=Local",
		cfg.User, cfg.Password, cfg.Host, cfg.Port, cfg.DBName)

	db, err := gorm.Open(mysql.Open(dsn), &gorm.Config{})
	if err != nil {
		return nil, err
	}

	// 自动迁移数据库模式
	err = db.AutoMigrate(
		&models.Ingredient{},
		&models.Recipe{},
		&models.RecipeIngredient{},
		&models.RecipeStep{},
		&models.RecipeNutrition{},
		&models.Banner{},
	)
	if err != nil {
		return nil, err
	}

	DB = db

	// 获取底层SQL数据库连接以便后续关闭
	sqlDB, err := db.DB()
	if err != nil {
		return nil, err
	}

	return sqlDB, nil
}
